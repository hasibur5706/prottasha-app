# Prottasha Academy — Android app (connected to https://prottashaacademy.com)

> The app is pre-configured for **https://prottashaacademy.com** — install the APK and log in with a student account. Only step 1 below is required on your server.

The app never talks to MySQL directly (that would put your database password inside the APK).
It calls your website's existing `/api/*` + `/chat-ws` + `/call-ws`, exactly like the website does; your server talks to the database.

## 1. Server (one-time) — add to your server `.env`
```
CHAT_ALLOWED_ORIGINS=https://localhost
```
Your chat and call WebSocket servers reject unknown origins; the Android app's origin is `https://localhost`.
Use **HTTPS** for your site (needed for camera/microphone and WebRTC). REST needs no change (CORS is open).

## 2. Build the APK
1. Push this folder to a GitHub repo (`main`).
2. Repo → **Settings → Secrets and variables → Actions → Variables → New variable**: `API_BASE` = `https://your-domain.com`
3. **Actions → Build APK** → download **Prottasha-Academy-APK** → install `app-debug.apk`.

The app is pre-set to your website address (see top). Theme (light/dark) choice is saved on the device.

## What is live (real data)
Login/register/forgot password · exams (online + OMR choice, start, submit, review, AI explain) · practice, adaptive, mock tests ·
question bank (folders, study/practice) · batches + class code · OMR sheet photo upload · leaderboard · courses (YouTube player, progress) ·
book store (catalog, cart, checkout, COD/online, orders, e-book download) · payments (gateway, bKash/Nagad/Rocket, bank, balance) ·
live support chat (agent name shown) · voice/video calls with support (incoming + outgoing, all-busy handling) · face attendance.

## Limits
- Calls/chat messages arrive only while the app is open (no push notifications yet — needs Firebase).
- Google sign-in is not available in the app (use email + password).
- Printing the blank OMR sheet is done on the website.
- The APK is a debug build (fine for testing; sign a release build for Play Store).

## Chat or calls not connecting?
1. In the app: open **Menu → সাপোর্ট চ্যাট**; if chat can't connect a banner appears with a **সংযোগ পরীক্ষা করো** button that shows which part fails.
2. Server `.env` must contain `CHAT_ALLOWED_ORIGINS=https://localhost` (then restart the server).
3. Check from a computer (should print `101 Switching Protocols`; `403 Forbidden` = origin not allowed):
   `curl -i -N -H "Connection: Upgrade" -H "Upgrade: websocket" -H "Sec-WebSocket-Version: 13" -H "Sec-WebSocket-Key: SGVsbG8=" -H "Origin: https://localhost" https://prottashaacademy.com/chat-ws`
   Repeat with `-H "Origin: https://prottashaacademy.com"`; if that one also fails, your hosting is not passing WebSockets through.
4. Calls on mobile data may need a TURN server (`CALL_TURN_URL`, `CALL_TURN_USERNAME`, `CALL_TURN_CREDENTIAL` in `.env`). An admin must be online in the admin panel to receive calls.

## Notifications (messages & calls)
- New support messages and incoming calls show a phone notification when the app is minimized, an in-app banner (with sound) when you're using the app, and an unread badge on the Menu tab.
- A missed call leaves a "মিসড কল" notification. Android 13+ asks for notification permission after login; test it in **Menu → নোটিফিকেশন সেটিং ও টেস্ট**.
- Works while the app is open or minimized. When Android fully closes the app, notifications need Firebase push (not included yet).

## Exam page (same as the website)
All questions on one scrolling page · sticky countdown (yellow <5 min, red <1 min) with auto-submit at zero and automatic retry if the network drops · progress bar + numbered jump chips · answers saved on the phone for live exams (survive app restarts) · start / submit confirmations · face verification when the exam requires it · hidden-result handling.
Results: grade, marks, rank, সব/সঠিক/ভুল/বাদ filters with counts, every option marked, **AI explanation written automatically as you scroll**, plus the deeper **“প্রত্যাশা ব্যাখ্যা”** button per question.
