# Prottasha Academy — Android app (connected to https://prottashaacademy.com)

> The app is pre-configured for **https://prottashaacademy.com** — install the APK and log in with a student account. Only step 1 below is required on your server.

The app never talks to MySQL directly (that would put your database password inside the APK).
It calls your website's existing `/api/*` + `/chat-ws` + `/call-ws`, exactly like the website does; your server talks to the database.

## 1. Server (one-time) — add to your server `.env`
```
CHAT_ALLOWED_ORIGINS=https://localhost
```
Your chat and call WebSocket servers reject unknown origins; the Android app's origin is `https://localhost`.
Use **HTTPS** for your site (needed for camera/microphone and WebRTC). REST needs no change (CORS is open).

## 2. Build the APK
1. Push this folder to a GitHub repo (`main`).
2. Repo → **Settings → Secrets and variables → Actions → Variables → New variable**: `API_BASE` = `https://your-domain.com`
3. **Actions → Build APK** → download **Prottasha-Academy-APK** → install `app-debug.apk`.

No variable? On first launch the installed app shows a **server connection screen**: type your website address (e.g. `https://your-domain.com`), tap *সংযোগ করো* — it checks the connection, saves it and reloads with your real data. You can change it later in **Menu → সার্ভার সেটিং**. (Demo data is only shown if you tap "ডেমো দেখো".)

## What is live (real data)
Login/register/forgot password · exams (online + OMR choice, start, submit, review, AI explain) · practice, adaptive, mock tests ·
question bank (folders, study/practice) · batches + class code · OMR sheet photo upload · leaderboard · courses (YouTube player, progress) ·
book store (catalog, cart, checkout, COD/online, orders, e-book download) · payments (gateway, bKash/Nagad/Rocket, bank, balance) ·
live support chat (agent name shown) · voice/video calls with support (incoming + outgoing, all-busy handling) · face attendance.

## Limits
- Calls/chat messages arrive only while the app is open (no push notifications yet — needs Firebase).
- Google sign-in is not available in the app (use email + password).
- Printing the blank OMR sheet is done on the website.
- The APK is a debug build (fine for testing; sign a release build for Play Store).
